package com.example.todoapp.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF8C8798)
val PurpleGrey80 = Color(0xFFBFBFC0)
val Pink80 = Color(0xFF777676)

val Purple40 = Color(0xFF3A3942)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)