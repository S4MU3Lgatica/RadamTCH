package com.example.todoapp.model

data class TodoItem(
    val id: Long,
    val title: String,
    var completed: Boolean = false
)
