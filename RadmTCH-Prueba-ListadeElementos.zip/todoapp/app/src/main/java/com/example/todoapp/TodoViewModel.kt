package com.example.todoapp

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import kotlin.random.Random
import com.example.todoapp.model.TodoItem

class TodoViewModel : ViewModel() {
    private val _items = mutableStateListOf<TodoItem>()
    val items: List<TodoItem> get() = _items


    fun addItem(title: String) {
        if (title.isBlank()) return
        val id = Random.nextLong()
        _items.add(0, TodoItem(id, title.trim()))
    }

    fun toggleCompleted(id: Long) {
        val idx = _items.indexOfFirst { it.id == id }
        if (idx >= 0) {
            _items[idx] = _items[idx].copy(completed = !_items[idx].completed)
        }
    }

    fun removeItem(id: Long) {
        _items.removeAll { it.id == id }
    }
}
