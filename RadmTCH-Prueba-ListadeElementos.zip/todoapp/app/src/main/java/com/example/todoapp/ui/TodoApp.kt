package com.example.todoapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.todoapp.TodoViewModel
import com.example.todoapp.model.TodoItem

@Composable
fun TodoApp(viewModel: TodoViewModel) {
    val items = viewModel.items

    var text by remember { mutableStateOf("")
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Lista de elementos") })
        }
    ) { padding ->Column(modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) { Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(  value = text, onValueChange = { text = it },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(25.dp),
                                    placeholder = { Text("Nuevo elemento")
                                    }

                )
                Button(onClick = {
                    viewModel.addItem(text)
                    text = "" }, modifier = Modifier.height(height = 55.dp),)
                { Text("Crear")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (items.isEmpty()) {
                Text("No hay tareas. Añade una arriba.", modifier = Modifier.padding(8.dp))
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items, key = { it.id }) { item ->
                        TodoRow(item, onToggle = { viewModel.toggleCompleted(it) }, onRemove = { viewModel.removeItem(it) })
                    }
                }
            }
        }
    }
}

@Composable
fun TodoRow(item: TodoItem, onToggle: (Long) -> Unit, onRemove: (Long) -> Unit) {
    Card(elevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Row(modifier = Modifier.weight(1f)) {
                Checkbox(checked = item.completed, onCheckedChange = { onToggle(item.id) })
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = item.title,
                    modifier = Modifier .padding(15.dp),
                    textDecoration = if (item.completed) TextDecoration.LineThrough else TextDecoration.None
                )
            }
            IconButton(onClick = { onRemove(item.id) }) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Eliminar")
            }
        }
    }
}
